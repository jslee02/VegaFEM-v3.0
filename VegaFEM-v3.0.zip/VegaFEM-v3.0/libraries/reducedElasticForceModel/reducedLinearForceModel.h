/*************************************************************************
 *                                                                       *
 * Vega FEM Simulation Library Version 3.0                               *
 *                                                                       *
 * "elasticForceModel" library , Copyright (C) 2007 CMU, 2009 MIT,       *
 *                                                       2016 USC        *
 * All rights reserved.                                                  *
 *                                                                       *
 * Code author: Jernej Barbic                                            *
 * http://www.jernejbarbic.com/code                                      *
 *                                                                       *
 * Research: Jernej Barbic, Fun Shing Sin, Daniel Schroeder,             *
 *           Doug L. James, Jovan Popovic                                *
 *                                                                       *
 * Funding: National Science Foundation, Link Foundation,                *
 *          Singapore-MIT GAMBIT Game Lab,                               *
 *          Zumberge Research and Innovation Fund at USC                 *
 *                                                                       *
 * This library is free software; you can redistribute it and/or         *
 * modify it under the terms of the BSD-style license that is            *
 * included with this library in the file LICENSE.txt                    *
 *                                                                       *
 * This library is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the file     *
 * LICENSE.TXT for more details.                                         *
 *                                                                       *
 *************************************************************************/

/*
  A reduced linear force model:
    f = K * u
*/

#ifndef _REDUCEDLINEARFORCEMODEL_H_
#define _REDUCEDLINEARFORCEMODEL_H_

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>

#include "reducedForceModel.h"

class ReducedLinearForceModel : public ReducedForceModel
{
public:
  
  ReducedLinearForceModel(int r, double * stiffnessMatrix); // makes an internal copy of the stiffness matrix
  virtual ~ReducedLinearForceModel();
  virtual void GetInternalForce(double * q, double * internalForces); // internalForce = stiffnessMatrix * q
  virtual void GetTangentStiffnessMatrix(double * q, double * tangentStiffnessMatrix);

protected:

  double * stiffnessMatrix; 
};

#endif

