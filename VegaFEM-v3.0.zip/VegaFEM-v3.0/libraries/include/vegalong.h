#ifndef vegalong

#include <stdint.h>
#define vegalong int64_t
#define vegaunsignedlong uint64_t

#endif

