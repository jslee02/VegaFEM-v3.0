#ifndef _SPARSESOLVER_AVAILABILITY_H_
#define _SPARSESOLVER_AVAILABILITY_H_

// uncomment the corresponding line if Pardiso or SPOOLES is installed and configured

//#define PARDISO_SOLVER_IS_AVAILABLE
//#define SPOOLES_SOLVER_IS_AVAILABLE

#endif

